<?php use_helper('I18N') ?>

<p><?php echo __("You don't have the required permission to access this page.") ?></p>
