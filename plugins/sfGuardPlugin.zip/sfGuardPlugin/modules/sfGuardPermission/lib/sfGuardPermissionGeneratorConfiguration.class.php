<?php

/**
 * sfGuardPermission module configuration.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardPermission
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfGuardPermissionGeneratorConfiguration.class.php 12896 2008-11-10 19:02:34Z fabien $
 */
class sfGuardPermissionGeneratorConfiguration extends BaseSfGuardPermissionGeneratorConfiguration
{
}
