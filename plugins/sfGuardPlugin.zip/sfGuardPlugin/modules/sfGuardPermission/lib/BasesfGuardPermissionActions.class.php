<?php

require_once dirname(__FILE__).'/sfGuardPermissionGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/sfGuardPermissionGeneratorHelper.class.php';

/**
 * sfGuardPermission actions.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardPermission
 * @author     Fabien Potencier
 * @version    SVN: $Id: BasesfGuardPermissionActions.class.php 12965 2008-11-13 06:02:38Z fabien $
 */
class BasesfGuardPermissionActions extends autosfGuardPermissionActions
{
}
