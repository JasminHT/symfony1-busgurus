<?php

/**
 * sfGuardUserGroup form.
 *
 * @package    form
 * @subpackage sf_guard_user_group
 * @version    SVN: $Id: sfGuardUserGroupForm.class.php 7745 2008-03-05 11:05:33Z fabien $
 */
class sfGuardUserGroupForm extends BasesfGuardUserGroupForm
{
  public function configure()
  {
  }
}
